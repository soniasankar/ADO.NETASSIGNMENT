﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ConsoleApp_OrderManagementSystem.Model;
using ConsoleApp_OrderManagementSystem;
using ConsoleApp_OrderManagementSystem.Repository;
using ConsoleApp_OrderManagementSystem.Service;
using System.Web;
namespace ConsoleApp_OrderManagementSystem
{
    public class OrderApp
    {
      
        static async Task Main(string[] args)
        {
            //Constructor injection
            IOrderServicee orderService = new OrderServiceImplementation(new OrderRepositoryImpl());
            bool exit = false;
            //menudriven
            while (!exit)
            {
                Console.WriteLine("\nOrder Management System");
                Console.WriteLine("1. Add New Book");
                Console.WriteLine("2. Update Book");
                Console.WriteLine("3. Search Book by Code");
                Console.WriteLine("4. Delete Book");
                Console.WriteLine("5. List All Books");
                Console.WriteLine("6. Exit");
                Console.WriteLine("Enter your choice:");
                //enter the choice
                string choiceGiven = Console.ReadLine();

                if (!int.TryParse(choiceGiven, out int choice) || choice > 6 || choice < 0)
                {
                    Console.WriteLine("Invalid choice.\n Please enter a choice between 1 and 6.");
                }

                switch (choice)
                {
                    case 1:
                        await AddOrder(orderService);
                        break;
                    case 2:
                        await UpdateOrder(orderService);
                        break;
                    case 3:
                        await SearchOrder(orderService);
                        break;
                    case 4:
                        await DeleteOrder(orderService);
                        break;
                    case 5:
                        await ListAllOrders(orderService);
                        break;
                    case 6:
                        exit = true;
                        break;
                    default:
                        Console.WriteLine("Invalid choice. Please enter a number between 1 and 6.");
                        break;
                }

            }

        }
        public static async Task AddOrder(IOrderServicee orderService)
        {
            //creating the object of orderclass
            Order order = new Order();

            while (true)
            {
                Console.Write("Enter the Order ID: ");
                order.OrderID = Console.ReadLine();

                if (!string.IsNullOrEmpty(order.OrderID))
                {
                    bool exists = await orderService.OrderIDExistsAsync(order.OrderID);
                    if (exists)
                    {
                        Console.WriteLine("Order ID already exists. Please enter a unique Order ID.");
                    }
                    else
                    {
                        break;
                    }
                }
                else
                {
                    Console.WriteLine("Order ID cannot be empty.");
                }
            }
            //Customer Name
            while (true)
            {
                //Input Customer name
                Console.Write("Enter Customer Name: ");
                order.CustomerName = Console.ReadLine();
                //check the Customer name is null or not
                if (string.IsNullOrEmpty(order.CustomerName))
                {
                    Console.WriteLine("Customer Name should be not null");
                }
                else
                {
                    break;
                }
            }

            //Product Code
            while (true)
            {
                //input product code 
                Console.Write("Enter Product Code: ");
                order.ProductCode = Console.ReadLine();
                if (string.IsNullOrEmpty(order.ProductCode))
                {
                    Console.WriteLine("Product code should not be empty");
                }
                else
                {
                    break;
                }
            }

            // Quantity
            while (true)
            {
                //Input quantity
                Console.Write("Enter Quantity: ");

                if (int.TryParse(Console.ReadLine(), out int quantity) && quantity > 0)
                {
                    order.Quantity = quantity;
                    break;

                }
                else
                {
                    Console.WriteLine("Invalid input for Quantity. It should be a positive number.");
                }
            }
            while (true)
            {
                Console.Write("Enter Total Price: ");

                //input is in datetime form and should not be a future value
                if (decimal.TryParse(Console.ReadLine(), out decimal totalprice) && totalprice > 0)
                {
                    order.TotalPrice = totalprice;
                    break;
                }
                else
                {
                    Console.WriteLine("Ivalid input for Total Price.\nEnter a Total Price greater than zero");
                }
            }
            while (true)
            {
                //add the product is availabe or not 
                Console.Write("Is the product available(yes/No): ");
                string pAvailable = Console.ReadLine().Trim().ToLower();
                if (pAvailable == "yes" || pAvailable == "y")
                {
                    order.IsAvailable = true;
                    break;
                }
                else if (pAvailable == "no" || pAvailable == "n")
                {
                    order.IsAvailable = false;
                    break;
                }
                else
                {
                    Console.WriteLine("Ivalid input.Please enter Yes or No");
                }

            }

            await orderService.AddOrderAsync(order);
            Console.WriteLine("Order details added successfully.");
        }
        //Method for Update order
        public static async Task UpdateOrder(IOrderServicee orderService)
        {
            string orderIdInput;
            while (true)
            {
                Console.Write("Enter the Order ID to Update: ");
                orderIdInput = Console.ReadLine();
                if (!string.IsNullOrEmpty(orderIdInput))
                {
                    break;
                }
                else
                {
                    Console.WriteLine("Order ID cannot be empty.");
                }
                
            }
            //store the details in a variable
            var existingOrder = await orderService.GetOrderByIDAsync(orderIdInput);
            if (existingOrder == null)
            {
                Console.WriteLine("Order ID not found.");
                return;
            }

            Console.WriteLine("Updating Order:");
            //show  current customername
            Console.Write($"Current Customer Name (current: {existingOrder.CustomerName}): ");
            string customerName = Console.ReadLine();
            //if not null then store the new data of name 
            if (!string.IsNullOrEmpty(customerName))
            {
                existingOrder.CustomerName = customerName;
            }

            Console.Write($"Current Product Code (current: {existingOrder.ProductCode}): ");
            string productCode = Console.ReadLine();
            //store updated product code
            if (!string.IsNullOrEmpty(productCode))
            {
                existingOrder.ProductCode = productCode;
            }
            
            Console.Write($"Current Quantity (current: {existingOrder.Quantity}): ");

            //update new quantity
            if (int.TryParse(Console.ReadLine(), out int quantity) && quantity > 0)
            {
                existingOrder.Quantity = quantity;
            }
            //show current total price
            Console.Write($"Current Total Price (current: {existingOrder.TotalPrice}): ");
            //update price

            if (decimal.TryParse(Console.ReadLine(), out decimal totalPrice) && totalPrice > 0)
            {
                existingOrder.TotalPrice = totalPrice;
            }

            //show is product Available or not
            Console.Write($"Current Availability (current: {(existingOrder.IsAvailable ? "Yes" : "No")}): ");
            string availability = Console.ReadLine().Trim().ToLower();
            if (availability == "yes" || availability == "y")
            {
                existingOrder.IsAvailable = true;
            }
            else if (availability == "no" || availability == "n")
            {
                existingOrder.IsAvailable = false;
            }

            await orderService.UpdateOrderAsync(orderIdInput, existingOrder);
            Console.WriteLine("Order updated successfully.");
        }
        //Method for searching
        public static async Task SearchOrder(IOrderServicee orderService)
        {
            //input id to search
            Console.Write("Enter the Order ID to Search: ");
            string orderId = Console.ReadLine();
            //get the details store it in variable
            var order = await orderService.GetOrderByIDAsync(orderId);
            if (order != null)
            {
                //disply details
                Console.WriteLine("\nOrder Details:");
                Console.WriteLine();
                Console.WriteLine("| {0,-12} | {1,-25} | {2,-15} | {3,-10} | {4,-12} | {5,-10} |",
                    "Order ID", "Customer Name", "Product Code", "Quantity", "Total Price", "Available");
                Console.WriteLine(new string('-', 101));
                Console.WriteLine("| {0,-12} | {1,-25} | {2,-15} | {3,-10} | {4,-12} | {5,-10} |",
                    order.OrderID, order.CustomerName, order.ProductCode, order.Quantity, order.TotalPrice, order.IsAvailable ? "Yes" : "No");
                Console.WriteLine(new string('-', 101));
            }
            else
            {
                Console.WriteLine("Order ID not found.");
            }
        }
        //Method for deleting the data
        public static async Task DeleteOrder(IOrderServicee orderService)
        {
            //input id to delete 
            Console.Write("Enter the Order ID to Delete: ");
            string orderId = Console.ReadLine();

            //get the details of corresponing orderId
            var orderExists = await orderService.OrderIDExistsAsync(orderId);
            if (orderExists)
            {
                await orderService.DeleteOrderAsync(orderId);
                Console.WriteLine("Order deleted successfully.");
                await ListAllOrders(orderService);

            }
            else
            {
                Console.WriteLine("Order ID not found.");
            }
        }
        //List of all orders
        public static async Task ListAllOrders(IOrderServicee orderService)
        {
            var orders = await orderService.GetAllOrdersAsync();
            if (orders.Count == 0)
            {
                Console.WriteLine("No orders found.");
                return;
            }

            //Display details
            Console.WriteLine("\nList of Orders:");
            Console.WriteLine();
            Console.WriteLine("| {0,-12} | {1,-25} | {2,-15} | {3,-10} | {4,-12} | {5,-10} |",
                "Order ID", "Customer Name", "Product Code", "Quantity", "Total Price", "Available");
            Console.WriteLine(new string('-', 101));

            foreach (var order in orders)
            {
                Console.WriteLine("| {0,-12} | {1,-25} | {2,-15} | {3,-10} | {4,-12} | {5,-10} |",
                    order.OrderID, order.CustomerName, order.ProductCode, order.Quantity, order.TotalPrice, order.IsAvailable ? "Yes" : "No");
            }
            Console.WriteLine(new string('-', 101));
        }
    }

}


