﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp_OrderManagementSystem.Model
{
    public class Order
    {
        //properties
        public string OrderID { get; set; }
        public string CustomerName { get; set; }
        public string ProductCode { get; set; }
        public int Quantity { get; set; }
        public decimal TotalPrice { get; set; }
        public bool IsAvailable { get; set; }

        //default constructor
        public Order() { }
        //parameterized construcor
       public Order(string orderID, string customerName, string productCode, int quantity, decimal totalPrice, bool isAvailable)
        {
            OrderID = orderID;
            CustomerName = customerName;
            ProductCode = productCode;
            Quantity = quantity;
            TotalPrice = totalPrice;
            IsAvailable = isAvailable;
        }
    }
}
