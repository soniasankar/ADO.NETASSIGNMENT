﻿using ConsoleApp_OrderManagementSystem.Model;
using ConsoleApp_OrderManagementSystem.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp_OrderManagementSystem.Service
{
    internal class OrderServiceImplementation : IOrderServicee
    {

        

    private readonly IOrderRepository _orderRepository;

        public OrderServiceImplementation(IOrderRepository orderRepository)
        {

            _orderRepository = orderRepository;
        }
        public async Task AddOrderAsync(Order order)
        {
            await _orderRepository.AddOrderAsync(order);
        }

        public async Task DeleteOrderAsync(string orderID)
        {
            await _orderRepository.DeleteOrderAsync(orderID);
        }
        public async Task<List<Order>> GetAllOrdersAsync()
        {
            return await _orderRepository.GetAllOrdersAsync();
        }

        public async Task<Order> GetOrderByIDAsync(string orderID)
        {
            return await _orderRepository.GetOrderByIDAsync(orderID);
        }

        public async Task<bool> OrderIDExistsAsync(string orderID)
        {
            return await _orderRepository.OrderIDExistsAsync(orderID);
        }

        public async Task UpdateOrderAsync(string orderID, Order updatedOrder)
        {
            await _orderRepository.UpdateOrderAsync(orderID, updatedOrder);
        }
    }
}
