﻿using ConsoleApp_OrderManagementSystem.Model;
using ConsoleApp_OrderManagementSystem.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp_OrderManagementSystem.Service
{
    public class OrderServiceImpl : IOrderService
    {
        private readonly IOrderRepository _orderRepository;

        //constructor injuction
        public OrderServiceImpl(IOrderRepository orderRepository)
        {

            _orderRepository = orderRepository;
        }
        //Method for add order
        public async Task AddOrderAsync(Order order)
        {
            await _orderRepository.AddOrderAsync(order);
        }
        //Method for delete Order
        public async Task DeleteOrderAsync(string orderID)
        {
            await _orderRepository.DeleteOrderAsync(orderID);
        }
        //Method for get all orders
        public async Task<List<Order>> GetAllOrdersAsync()
        {
            return await _orderRepository.GetAllOrdersAsync();
        }
        //Method for find order details using OrderId
        public async Task<Order> GetOrderByIDAsync(string orderID)
        {
            return await _orderRepository.GetOrderByIDAsync(orderID);
        }
        //Method for checking the specified id is exist or not
        public async Task<bool> OrderIDExistsAsync(string orderID)
        {
            return await _orderRepository.OrderIDExistsAsync(orderID);
        }
        //Method for Updating the Order details
        public async Task UpdateOrderAsync(string orderID, Order updatedOrder)
        {
            await _orderRepository.UpdateOrderAsync(orderID, updatedOrder);
        }
    }
    
}
