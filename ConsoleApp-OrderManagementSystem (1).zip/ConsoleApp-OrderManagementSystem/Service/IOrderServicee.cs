﻿using ConsoleApp_OrderManagementSystem.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp_OrderManagementSystem.Service
{
    public interface IOrderServicee
    {

        //Addd orderdetails
        Task AddOrderAsync(Order order);
        //Update orderdetails
        Task UpdateOrderAsync(string orderID, Order updatedOrder);
        //method for finding orderdetails using orderid
        Task<Order> GetOrderByIDAsync(string orderID);
        //ListAllOrder
        Task<List<Order>> GetAllOrdersAsync();
        //Delete the Orderdetails
        Task DeleteOrderAsync(string orderID);
        //check the OrderId exist or not
        Task<bool> OrderIDExistsAsync(string orderID);
    }
}
