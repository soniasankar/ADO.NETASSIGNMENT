﻿using ConsoleApp_OrderManagementSystem.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;
using SqlServerConnectionLibrary;
using System.Data.SqlClient;
using System.Data;

namespace ConsoleApp_OrderManagementSystem.Repository
{
    public class OrderRepositoryImpl : IOrderRepository
    {
        private readonly string conString = ConfigurationManager.ConnectionStrings["CsWin"].ConnectionString;

        #region Add order
        public async Task AddOrderAsync(Order order)
        {
            //order function
            //open connecton
            try
            {
                using (SqlConnection conn = SqlServerConnectionManager.OpenConnection(conString))
                {
                    //query for inserting values
                    string query = "INSERT INTO Orders (OrderID, CustomerName, ProductCode, Quantity, TotalPrice, IsAvailable) " +
                                       "VALUES (@OrderID, @CustomerName, @ProductCode, @Quantity, @TotalPrice, @IsAvailable)";
                    //sqlcommant for exicuting commands
                    using (SqlCommand command = new SqlCommand(query, conn))
                    {
                        //get values from user
                        command.Parameters.AddWithValue("@OrderID", order.OrderID);
                        command.Parameters.AddWithValue("@CustomerName", order.CustomerName);
                        command.Parameters.AddWithValue("@ProductCode", order.ProductCode);
                        command.Parameters.AddWithValue("@Quantity", order.Quantity);
                        command.Parameters.AddWithValue("@TotalPrice", order.TotalPrice);
                        command.Parameters.AddWithValue("@IsAvailable", order.IsAvailable);

                        await command.ExecuteNonQueryAsync();
                    }
                }
            }
            catch (Exception ex)
            {
                throw new ApplicationException("Error retrieving order by ID", ex);
            }
        }
        #endregion

        #region DeleteOrder
        public async Task DeleteOrderAsync(string orderID)
        {
            try
            {
                using (SqlConnection conn = SqlServerConnectionManager.OpenConnection(conString))
                {
                    //query for setting value of Isavailabe to zero 
                    string query = "UPDATE Orders SET IsAvailable = 0 WHERE OrderID = @OrderID";
                    using (SqlCommand command = new SqlCommand(query, conn))
                    {
                        command.Parameters.AddWithValue("@OrderID", orderID);
                        await command.ExecuteNonQueryAsync();
                    }
                }
            }
            catch (Exception ex)
            {
                throw new ApplicationException("Error marking order as unavailable", ex);
            }
        }



        #endregion


        #region ListOfOreder
        public async Task<List<Order>> GetAllOrdersAsync()
        {
            try
            {
                //list for storing the details
                var orders = new List<Order>();

                using (SqlConnection conn = SqlServerConnectionManager.OpenConnection(conString))
                {

                    string query = "SELECT * FROM Orders";

                    using (SqlCommand command = new SqlCommand(query, conn))
                    {
                        using (SqlDataReader reader = await command.ExecuteReaderAsync())
                        {
                            while (await reader.ReadAsync())
                            {
                                orders.Add(new Order
                                {
                                    OrderID = reader["OrderID"].ToString(),
                                    CustomerName = reader["CustomerName"].ToString(),
                                    ProductCode = reader["ProductCode"].ToString(),
                                    Quantity = Convert.ToInt32(reader["Quantity"]),
                                    TotalPrice = Convert.ToDecimal(reader["TotalPrice"]),
                                    IsAvailable = Convert.ToBoolean(reader["IsAvailable"])
                                });
                            }
                        }
                    }
                }
                return orders;
            }
            catch (Exception ex)
            {
                throw new ApplicationException("Error listing orders", ex);
            }
        }
        #endregion

        #region search 
        public async Task<Order> GetOrderByIDAsync(string orderID)
        {
            try
            {
                using (SqlConnection conn = SqlServerConnectionManager.OpenConnection(conString))
                {
                    //query for get the details based on OrderId
                    string query = "SELECT * FROM Orders WHERE OrderID=@OrderID";
                    using (SqlCommand command = new SqlCommand(query, conn))
                    {
                        //give the OrderId for the data fetching 
                        command.Parameters.AddWithValue("@OrderId", orderID);
                        //use datareader for reading the record
                        using (SqlDataReader reader = await command.ExecuteReaderAsync())
                        {
                            //read the record if exist
                            if (await reader.ReadAsync())
                            {
                                //retrive the corresponding data
                                return new Order
                                {
                                    OrderID = reader["OrderID"].ToString(),
                                    CustomerName = reader["CustomerName"].ToString(),
                                    ProductCode = reader["ProductCode"].ToString(),
                                    Quantity = Convert.ToInt32(reader["Quantity"]),
                                    TotalPrice = Convert.ToDecimal(reader["TotalPrice"]),
                                    IsAvailable = Convert.ToBoolean(reader["IsAvailable"])


                                };
                            }
                            else
                            {
                                return null;
                            }
                        }

                    }
                }
            }
            catch (Exception e)
            {
                throw new ApplicationException("Error in retriving the data", e);

            }
        }

        #endregion

        #region order exist
        public async Task<bool> OrderIDExistsAsync(string orderID)
        {
            try
            {
                //give the connection
                using (SqlConnection conn = SqlServerConnectionManager.OpenConnection(conString))
                {
                    //Query for counting no of oreder with same orderid

                    string query = "SELECT COUNT(1) FROM Orders WHERE OrderID=@OrderID";
                    
                    using (SqlCommand command = new SqlCommand(query, conn))

                    {
                        command.Parameters.AddWithValue("@OrderId", orderID);
                        //store the count
                        int count = (int)await command.ExecuteScalarAsync();
                        return (count > 0);
                    }


                }

            }
            catch (Exception e)
            {
                throw new ApplicationException("error in orderId existance checking", e);
            }
        }
        #endregion

        #region Update
        public async Task UpdateOrderAsync(string orderID, Order updateOrder)
        {
            try
            {

                using (SqlConnection conn = SqlServerConnectionManager.OpenConnection(conString))
                {
                    //query for updation
                    string query = "UPDATE Orders SET CustomerName=@CustomerName,ProductCode=@ProductCode,Quantity=@Quantity,TotalPrice=@TotalPrice,IsAvailable=@IsAvailable WHERE OrderId=@OrderId";

                    using (SqlCommand command = new SqlCommand(query, conn))

                        //update the details
                     {
                        command.Parameters.AddWithValue("@OrderID", orderID);
                        command.Parameters.AddWithValue("@CustomerName", updateOrder.CustomerName);
                        command.Parameters.AddWithValue("@ProductCode", updateOrder.ProductCode);
                        command.Parameters.AddWithValue("@Quantity", updateOrder.Quantity);
                        command.Parameters.AddWithValue("@TotalPrice", updateOrder.TotalPrice);
                        command.Parameters.AddWithValue("@IsAvailable", updateOrder.IsAvailable);

                        await command.ExecuteNonQueryAsync();
                    }
                
                }
            }
            catch(Exception e) { throw new ApplicationException("Error in updating Book",e); }
        }
        #endregion

    } 
}
