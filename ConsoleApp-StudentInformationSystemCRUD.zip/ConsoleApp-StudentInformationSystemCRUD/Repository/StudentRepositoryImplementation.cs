﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Configuration;
using ConsoleApp_StudentInformationSystemCRUD.Model;
using SqlServerConnectionLibrary;

namespace ConsoleApp_StudentInformationSystemCRUD.Repository
{
    public class StudentRepositoryImplementation:IStudentRepository
    {
      //retrive the connection
            private readonly string conString = ConfigurationManager.ConnectionStrings["CsWin"].ConnectionString;

        //add studnet method
            #region AddStudent
            public async Task AddStudentAsync(Student student)
            {
                try
                {
                //open connection
                    using (SqlConnection conn = SqlServerConnectionManager.OpenConnection(conString))
                    {
                        //insert query
                        string query = "INSERT INTO Student (StudentID, StudentName, Course, EnrollmentDate, GPA, IsPresent) " +
                                       "VALUES (@StudentID, @StudentName, @Course, @EnrollmentDate, @GPA, @IsPresent)";

                    //Execute sql command with this query and the connection
                        using (SqlCommand command = new SqlCommand(query, conn))
                        {
                        //add input to the parameters
                            command.Parameters.AddWithValue("@StudentID", student.StudentID);
                            command.Parameters.AddWithValue("@StudentName", student.StudentName);
                            command.Parameters.AddWithValue("@Course", student.Course);
                            command.Parameters.AddWithValue("@EnrollmentDate", student.EnrollmentDate);
                            command.Parameters.AddWithValue("@GPA", student.GPA);
                            command.Parameters.AddWithValue("@IsPresent", student.IsPresent);

                            await command.ExecuteNonQueryAsync();
                        }
                    }
                }
                catch (SqlException sqlEx)
                {
                    throw new ApplicationException("Database error occurred while adding student.", sqlEx);
                }
                catch (Exception ex)
                {
                    throw new ApplicationException("Error occurred while adding student.", ex);
                }
            }
            #endregion

            #region UpdateStudent

        //Update student details
            public async Task UpdateStudentAsync(string studentID, Student updatedStudent)
            {
                try
                {
                //open connection
                    using (SqlConnection conn = SqlServerConnectionManager.OpenConnection(conString))
                    {
                        //update query
                        string query = "UPDATE Student SET StudentName=@StudentName, Course=@Course, EnrollmentDate=@EnrollmentDate, GPA=@GPA, IsPresent=@IsPresent " +
                                       "WHERE StudentID=@StudentID";

                    //execute sqlcommand
                        using (SqlCommand command = new SqlCommand(query, conn))
                        {
                            command.Parameters.AddWithValue("@StudentID", studentID);
                            command.Parameters.AddWithValue("@StudentName", updatedStudent.StudentName);
                            command.Parameters.AddWithValue("@Course", updatedStudent.Course);
                            command.Parameters.AddWithValue("@EnrollmentDate", updatedStudent.EnrollmentDate);
                            command.Parameters.AddWithValue("@GPA", updatedStudent.GPA);
                            command.Parameters.AddWithValue("@IsPresent", updatedStudent.IsPresent);

                            await command.ExecuteNonQueryAsync();
                        }
                    }
                }
                catch (SqlException sqlEx)
                {
                    throw new ApplicationException("Database error occurred while updating student.", sqlEx);
                }
                catch (Exception ex)
                {
                    throw new ApplicationException("Error occurred while updating student.", ex);
                }
            }
            #endregion

            #region DeleteStudent
        //Delete the student details
            public async Task DeleteStudentAsync(string studentID)
            {
                try
                {
                //establish the connection
                    using (SqlConnection conn = SqlServerConnectionManager.OpenConnection(conString))
                    {
                       //query for delete
                        string query = "UPDATE Student SET IsPresent = 0 WHERE StudentID=@StudentID";

                        //Execute Sqlcommand
                        using (SqlCommand command = new SqlCommand(query, conn))
                        {
                        //add input value to parameters
                            command.Parameters.AddWithValue("@StudentID", studentID);
                            await command.ExecuteNonQueryAsync();
                        }
                    }
                }
                catch (SqlException sqlEx)
                {
                    throw new ApplicationException("Database error occurred while deleting student.", sqlEx);
                }
                catch (Exception ex)
                {
                    throw new ApplicationException("Error occurred while deleting student.", ex);
                }
            }
            #endregion

            #region GetStudentByID
        //Method for fetching for student details basedon StudentId
            public async Task<Student> GetStudentByIDAsync(string studentID)
            {
                try
                {
                //open connection
                    using (SqlConnection conn = SqlServerConnectionManager.OpenConnection(conString))
                    {
                       //query for getting the data
                        string query = "SELECT * FROM Student WHERE StudentID=@StudentID";
                        //Execute sqlcommand
                        using (SqlCommand command = new SqlCommand(query, conn))
                        {
                        //add input to the parameters
                            command.Parameters.AddWithValue("@StudentID", studentID);
                            //use datareader for reading the data
                            using (SqlDataReader reader = await command.ExecuteReaderAsync())
                            {
                            //fetch the record one by one if exist
                                if (await reader.ReadAsync())
                                {
                                    return new Student
                                    {
                                        StudentID = reader["StudentID"].ToString(),
                                        StudentName = reader["StudentName"].ToString(),
                                        Course = reader["Course"].ToString(),
                                        EnrollmentDate = Convert.ToDateTime(reader["EnrollmentDate"]),
                                        GPA = Convert.ToDecimal(reader["GPA"]),
                                        IsPresent = Convert.ToBoolean(reader["IsPresent"])
                                    };
                                }
                                return null;
                            }
                        }
                    }
                }
                catch (SqlException sqlEx)
                {
                    throw new ApplicationException("Database error occurred while retrieving student by ID.", sqlEx);
                }
                catch (Exception ex)
                {
                    throw new ApplicationException("Error occurred while retrieving student by ID.", ex);
                }
            }
            #endregion
        //List of all students
            #region GetAllStudents
            public async Task<List<Student>> GetAllStudentsAsync()
            {
                try
                {
                //List for storing data
                    var students = new List<Student>();
                //open Connection
                    using (SqlConnection conn = SqlServerConnectionManager.OpenConnection(conString))
                    {
                        //select all student details
                        string query = "SELECT * FROM Student "; 

                        using (SqlCommand command = new SqlCommand(query, conn))
                        {
                            using (SqlDataReader reader = await command.ExecuteReaderAsync())
                            {
                                while (await reader.ReadAsync())
                                {
                                //Add the student details in the list
                                    students.Add(new Student
                                    {
                                        StudentID = reader["StudentID"].ToString(),
                                        StudentName = reader["StudentName"].ToString(),
                                        Course = reader["Course"].ToString(),
                                        EnrollmentDate = Convert.ToDateTime(reader["EnrollmentDate"]),
                                        GPA = Convert.ToDecimal(reader["GPA"]),
                                        IsPresent = Convert.ToBoolean(reader["IsPresent"])
                                    });
                                }
                            }
                        }
                    }
                    return students;
                }
                catch (SqlException sqlEx)
                {
                    throw new ApplicationException("Database error occurred while listing all students.", sqlEx);
                }
                catch (Exception ex)
                {
                    throw new ApplicationException("Error occurred while listing all students.", ex);
                }
            }
            #endregion

            //Method for checking the studentId exist or not
            #region StudentIDExists
            public async Task<bool> StudentIDExistsAsync(string studentID)
            {
                try
                {
                //open connection
                using (SqlConnection conn = SqlServerConnectionManager.OpenConnection(conString))
                {
                      //fetch the number of row which have same studentID
                        string query = "SELECT COUNT(1) FROM Student WHERE StudentID=@StudentID";
                        //Execute sql command
                        using (SqlCommand command = new SqlCommand(query, conn))
                        {
                        //add input to the parameters
                            command.Parameters.AddWithValue("@StudentID", studentID);
                            int count = (int)await command.ExecuteScalarAsync();
                            return count > 0;
                        }
                    }
                }
                catch (SqlException sqlEx)
                {
                    throw new ApplicationException("Database error occurred while checking student ID existence.", sqlEx);
                }
                catch (Exception ex)
                {
                    throw new ApplicationException("Error occurred while checking student ID existence.", ex);
                }
            }
            #endregion

        }
    }
