﻿using ConsoleApp_StudentInformationSystemCRUD.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp_StudentInformationSystemCRUD.Repository
{
    //methods without implementation
    public interface IStudentRepository
    {
        //method for add
        Task AddStudentAsync(Student student);
        //method for update
        Task UpdateStudentAsync(string studentID, Student updatedStudent);
        //method for searching a particular student based on their id
        Task<Student> GetStudentByIDAsync(string studentID);
        //List all student details
        Task<List<Student>> GetAllStudentsAsync();
       //delete the student details based on studentid
        Task DeleteStudentAsync(string studentID);
        //check whether the studentid exist or not
        Task<bool> StudentIDExistsAsync(string studentID);
        
    }
}

