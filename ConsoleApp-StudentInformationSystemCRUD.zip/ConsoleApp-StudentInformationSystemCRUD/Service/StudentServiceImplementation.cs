﻿using ConsoleApp_StudentInformationSystemCRUD.Model;
using ConsoleApp_StudentInformationSystemCRUD.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp_StudentInformationSystemCRUD.Service
{
    public class StudentServiceImplemetation : IStudentService
    {
       private readonly IStudentRepository _studentRepository;
        public StudentServiceImplemetation(IStudentRepository studentRepository)
        {
            _studentRepository = studentRepository;
        }
        public async Task AddStudentAsync(Student student)
        {
           await _studentRepository.AddStudentAsync(student);
        }

        public async Task DeleteStudentAsync(string studentID)
        {
            await _studentRepository.DeleteStudentAsync(studentID);
        }

        public async Task<List<Student>> GetAllStudentsAsync()
        {
            return await _studentRepository.GetAllStudentsAsync();
        }

        public async Task<Student> GetStudentByIDAsync(string studentID)
        {
            return await _studentRepository.GetStudentByIDAsync(studentID);
        }

        public async Task<bool> StudentIDExistsAsync(string studentID)
        {
            return await _studentRepository.StudentIDExistsAsync(studentID);
        }

        public async Task UpdateStudentAsync(string studentID, Student updatedStudent)
        {
             await _studentRepository.UpdateStudentAsync(studentID, updatedStudent);
        }
    }
}
