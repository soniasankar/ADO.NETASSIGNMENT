﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp_StudentInformationSystemCRUD.Model
{
    public class Student
    {
        public string StudentID { get; set; }
        public string StudentName { get; set; }
        public string Course { get; set; }
        public DateTime EnrollmentDate { get; set; }
        public decimal GPA { get; set; }
        public bool IsPresent { get; set; }

        public Student() { }
        public Student(string studentID, string studentName, string course, DateTime enrollmentDate, decimal gPA, bool isPresent)
        {
            StudentID = studentID;
            StudentName = studentName;
            Course = course;
            EnrollmentDate = enrollmentDate;
            GPA = gPA;
            IsPresent = isPresent;
        }
    }
}