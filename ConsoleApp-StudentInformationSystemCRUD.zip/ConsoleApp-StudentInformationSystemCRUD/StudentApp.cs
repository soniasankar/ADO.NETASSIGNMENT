﻿using ConsoleApp_StudentInformationSystemCRUD.Service;
using ConsoleApp_StudentInformationSystemCRUD.Model;
using ConsoleApp_StudentInformationSystemCRUD.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp_StudentInformationSystemCRUD
{
    public class StudentApp
    {
        static async Task Main(string[] args)
        {
            // Constructor Injection
            IStudentService studentService = new StudentServiceImplemetation(new StudentRepositoryImplementation());
            bool exit = false;

            // Menu-driven loop
            while (!exit)
            {
                Console.WriteLine("\nStudent Management System");
                Console.WriteLine("1. Add New Student");
                Console.WriteLine("2. Update Student");
                Console.WriteLine("3. Search Student by ID");
                Console.WriteLine("4. Delete Student");
                Console.WriteLine("5. List All Students");
                Console.WriteLine("6. Exit");
                Console.Write("Enter your choice: ");

                string choiceGiven = Console.ReadLine();
                //validation for choice
                if (!int.TryParse(choiceGiven, out int choice) || choice > 6 || choice < 1)
                {
                    Console.WriteLine("Invalid choice. Please enter a number between 1 and 6.");
                    continue;
                }

                switch (choice)
                {
                    case 1:
                        await AddStudent(studentService);
                        break;
                    case 2:
                        await UpdateStudent(studentService);
                        break;
                    case 3:
                        await SearchStudent(studentService);
                        break;
                    case 4:
                        await DeleteStudent(studentService);
                        break;
                    case 5:
                        await ListAllStudents(studentService);
                        break;
                    case 6:
                        exit = true;
                        break;
                }
            }
        }

        //add student
        public static async Task AddStudent(IStudentService studentService)
        {
            Student student = new Student();

            while (true)
            {
                //Enter the studentId
                Console.Write("Enter Student ID: ");
                student.StudentID = Console.ReadLine();

                if (!string.IsNullOrEmpty(student.StudentID))
                {
                    bool exists = await studentService.StudentIDExistsAsync(student.StudentID);
                    if (exists)
                    {
                        Console.WriteLine("Student ID already exists. Please enter a unique Student ID.");
                    }
                    else
                    {
                        break;
                    }
                }
                else
                {
                    Console.WriteLine("Student ID cannot be empty.");
                }
            }

            while (true)
            {
                //Enter Student Name
                Console.Write("Enter Student Name: ");
                student.StudentName = Console.ReadLine();
                if (string.IsNullOrEmpty(student.StudentName))
                {
                    Console.WriteLine("Student Name cannot be empty.");
                }
                else
                {
                    break;
                }
            }

            while (true)
            {
                //Enter Course details
                Console.Write("Enter Course: ");
                student.Course = Console.ReadLine();
                if (string.IsNullOrEmpty(student.Course))
                {
                    Console.WriteLine("Course cannot be empty.");
                }
                else
                {
                    break;
                }
            }
            //Enrollment date
            while (true)
            {
                Console.Write("Enter Enrollment Date (yyyy-mm-dd): ");
                if (DateTime.TryParse(Console.ReadLine(), out DateTime enrollmentDate) && enrollmentDate <= DateTime.Now)
                {
                    student.EnrollmentDate = enrollmentDate;
                    break;
                }
                else
                {
                    Console.WriteLine("Invalid date. Please enter a valid date in yyyy-mm-dd format and ensure it's not a future date.");
                }
            }

            while (true)
            {
                //GPA
                Console.Write("Enter GPA: ");
                if (decimal.TryParse(Console.ReadLine(), out decimal gpa) && gpa >= 0.0m && gpa <= 10.0m)
                {
                    student.GPA = gpa;
                    break;
                }
                else
                {
                    Console.WriteLine("Invalid GPA. It should be between 0.0 and 4.0.");
                }
            }

            //IsPresent
            while (true)
            {
                Console.Write("Is the student present (yes/no): ");
                string presence = Console.ReadLine().Trim().ToLower();
                if (presence == "yes" || presence == "y")
                {
                    student.IsPresent = true;
                    break;
                }
                else if (presence == "no" || presence == "n")
                {
                    student.IsPresent = false;
                    break;
                }
                else
                {
                    Console.WriteLine("Invalid input. Please enter 'yes' or 'no'.");
                }
            }

            await studentService.AddStudentAsync(student);
            Console.WriteLine("Student added successfully.");
        }
        //Method for update
        public static async Task UpdateStudent(IStudentService studentService)
        {
            string studentIdInput;
            while (true)
            {
                //give the studentid
                Console.Write("Enter the Student ID to Update: ");
                studentIdInput = Console.ReadLine();
                if (!string.IsNullOrEmpty(studentIdInput))
                {
                    break;
                }
                else
                {
                    Console.WriteLine("Student ID cannot be empty.");
                }
            }
            //Collect the data from database and store in a variable
            var existingStudent = await studentService.GetStudentByIDAsync(studentIdInput);
            if (existingStudent == null)
            {
                Console.WriteLine("Student ID not found.");
                return;
            }

            //Updating the student details
            Console.WriteLine("Updating Student:");
            //update the student name
            Console.Write($"Current Student Name (current: {existingStudent.StudentName}): ");
            string studentName = Console.ReadLine();
            if (!string.IsNullOrEmpty(studentName))
            {
                existingStudent.StudentName = studentName;
            }

            //update the course
            Console.Write($"Current Course (current: {existingStudent.Course}): ");
            string course = Console.ReadLine();
            if (!string.IsNullOrEmpty(course))
            {
                existingStudent.Course = course;
            }

            //update the current Enrollment date
            Console.Write($"Current Enrollment Date (current: {existingStudent.EnrollmentDate:yyyy-MM-dd}): ");
            if (DateTime.TryParse(Console.ReadLine(), out DateTime enrollmentDate) && enrollmentDate <= DateTime.Now)
            {
                existingStudent.EnrollmentDate = enrollmentDate;
            }

            //update the GPA
            Console.Write($"Current GPA (current: {existingStudent.GPA}): ");
            if (decimal.TryParse(Console.ReadLine(), out decimal gpa) && gpa >= 0.0m && gpa <= 4.0m)
            {
                existingStudent.GPA = gpa;
            }

            //Update the present status
            Console.Write($"Current Presence Status (current: {(existingStudent.IsPresent ? "Yes" : "No")}): ");
            string presence = Console.ReadLine().Trim().ToLower();
            if (presence == "yes" || presence == "y")
            {
                existingStudent.IsPresent = true;
            }
            else if (presence == "no" || presence == "n")
            {
                existingStudent.IsPresent = false;
            }

            await studentService.UpdateStudentAsync(studentIdInput, existingStudent);
            Console.WriteLine("Student updated successfully.");
        }

        //for search Method
        public static async Task SearchStudent(IStudentService studentService)
        {
            //Enter the id of student we want to fetch
            Console.Write("Enter the Student ID to Search: ");
            string studentId = Console.ReadLine();
            var student = await studentService.GetStudentByIDAsync(studentId);
            if (student != null)
            {
                //display the details
                Console.WriteLine("\nStudent Details:");
                Console.WriteLine();
                Console.WriteLine("| {0,-12} | {1,-20} | {2,-20} | {3,-15} | {4,-6} | {5,-10} |",
                    "Student ID", "Name", "Course", "Enrollment Date", "GPA", "Present");
                Console.WriteLine(new string('-', 88));
                Console.WriteLine("| {0,-12} | {1,-20} | {2,-20} | {3,-15} | {4,-6} | {5,-10} |",
                    student.StudentID, student.StudentName, student.Course, student.EnrollmentDate.ToString("yyyy-MM-dd"), student.GPA, student.IsPresent ? "Yes" : "No");
                Console.WriteLine(new string('-', 88));
            }
            else
            {
                Console.WriteLine("Student ID not found.");
            }
        }

        //Delete the student details
        public static async Task DeleteStudent(IStudentService studentService)
        {//Enter the student Id to delete
            Console.Write("Enter the Student ID to Delete: ");
            string studentId = Console.ReadLine();

            //Store the data in a variable
            var studentExists = await studentService.StudentIDExistsAsync(studentId);
            if (studentExists)
            {
                //delete the student data
                await studentService.DeleteStudentAsync(studentId);
                Console.WriteLine("Student deleted successfully.");
                await ListAllStudents(studentService);
            }
            else
            {
                Console.WriteLine("Student ID not found.");
            }
        }
        //Show all student details
        public static async Task ListAllStudents(IStudentService studentService)
        {
            //Get all student details
            var students = await studentService.GetAllStudentsAsync();
            if (students.Count == 0)
            {
                Console.WriteLine("No students found.");
                return;
            }
            //Display the deatils
            Console.WriteLine("\nList of Students:");
            Console.WriteLine();
            Console.WriteLine("| {0,-12} | {1,-20} | {2,-20} | {3,-15} | {4,-6} | {5,-10} |",
                "Student ID", "Name", "Course", "Enrollment Date", "GPA", "Present");
            Console.WriteLine(new string('-', 88));

            foreach (var student in students)
            {
                Console.WriteLine("| {0,-12} | {1,-20} | {2,-20} | {3,-15} | {4,-6} | {5,-10} |",
                    student.StudentID, student.StudentName, student.Course, student.EnrollmentDate.ToString("yyyy-MM-dd"), student.GPA, student.IsPresent ? "Yes" : "No");
            }

            Console.WriteLine(new string('-', 88));
        }
    }
}
