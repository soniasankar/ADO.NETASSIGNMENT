﻿using ConsoleApp_InventaryManagementSystem.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp_InventaryManagementSystem.Repository
{
    //Method decleration
    public interface IProductRepository
    {
        //Method for add
        Task AddProductAsync(Product product);
        //Method for update
        Task UpdateProductAsync(string productCode, Product updatedProduct);
        //Method for Search for a particula product
        Task<Product> GetProductByCodeAsync(string productCode);
        //List of all products
        Task<List<Product>> GetAllProductsAsync();
        //delete product
        Task DeleteProductAsync(string productCode);
        //check the product code exist or not
        Task<bool> ProductCodeExistsAsync(string productCode);
    }
}
