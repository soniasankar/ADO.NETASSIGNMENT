﻿using ConsoleApp_InventaryManagementSystem.Model;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Threading.Tasks;
using SqlServerConnectionLibrary;

namespace ConsoleApp_InventaryManagementSystem.Repository
{
    public class ProductRepositoryImplementation : IProductRepository
    {
        //Retrive the conncetion from app.config
        private readonly string winconnString = ConfigurationManager.ConnectionStrings["CsWin"].ConnectionString;

        //Method for Adding product
        public async Task AddProductAsync(Product product)
        {
            try
            {
                //Open the database connection
                using (SqlConnection conn = SqlServerConnectionManager.OpenConnection(winconnString))
                {
                    //Query for data inserting
                    string query = "INSERT INTO Product (ProductCode, ProductName, Category, Quantity, UnitPrice, IsAvailable) " +
                                   "VALUES (@ProdCode, @ProdName, @Category, @Quantity, @UnitPrice, @IsAvailable)";
                    //Execute sqlcommand
                    using (SqlCommand command = new SqlCommand(query, conn))
                    {
                        //add values with user input
                        command.Parameters.AddWithValue("@ProdCode", product.ProductCode);
                        command.Parameters.AddWithValue("@ProdName", product.ProductName);
                        command.Parameters.AddWithValue("@Category", product.Category);
                        command.Parameters.AddWithValue("@Quantity", product.Quantity);
                        command.Parameters.AddWithValue("@UnitPrice", product.UnitPrice);
                        command.Parameters.AddWithValue("@IsAvailable", product.IsAvailable);

                        await command.ExecuteNonQueryAsync();
                    }
                }
            }
            //error handling
            catch (Exception ex)
            {
                throw new ApplicationException("Error adding product", ex);
            }
        }

        //Delete a particular product
        public async Task DeleteProductAsync(string productCode)
        {
            try
            {
                //Open connection
                using (SqlConnection conn = SqlServerConnectionManager.OpenConnection(winconnString))
                {
                    //query for deleting the data
                    string query = "UPDATE Product SET IsAvailable = 0 WHERE ProductCode = @ProdCode";
                    //for running sql command over database
                    using (SqlCommand command = new SqlCommand(query, conn))
                    {
                        command.Parameters.AddWithValue("@ProdCode", productCode);
                        await command.ExecuteNonQueryAsync();
                    }
                }
            }
            catch (Exception ex)
            {
                throw new ApplicationException("Error deleting product", ex);
            }
        }
        //List all product details
        public async Task<List<Product>> GetAllProductsAsync()
        {
            try
            {
                //use a list to store the retraived details
                var products = new List<Product>();
                //Open the database connection
                using (SqlConnection conn = SqlServerConnectionManager.OpenConnection(winconnString))
                {
                    //Query for selecting the data
                    string query = "SELECT * FROM Product";
                    //Execute sqlcommand aginst database
                    using (SqlCommand command = new SqlCommand(query, conn))
                    {
                        //for reading each record
                        using (SqlDataReader reader = await command.ExecuteReaderAsync())
                        {
                            //readAsync will give true if there is remainig records for reading 
                            while (await reader.ReadAsync())
                            {
                                //If true add the data list
                                products.Add(new Product
                                {
                                    ProductCode = reader["ProductCode"].ToString(),
                                    ProductName = reader["ProductName"].ToString(),
                                    Category = reader["Category"].ToString(),
                                    Quantity = Convert.ToInt32(reader["Quantity"]),
                                    UnitPrice = Convert.ToDecimal(reader["UnitPrice"]),
                                    IsAvailable = Convert.ToBoolean(reader["IsAvailable"])
                                });
                            }
                        }
                    }
                }
                return products;
            }
            catch (Exception ex)
            {
                throw new ApplicationException("Error listing products", ex);
            }
        }
        //get the details of a product based on the id given
        public async Task<Product> GetProductByCodeAsync(string productCode)
        {
            try
            {
                //Open connection
                using (SqlConnection conn = SqlServerConnectionManager.OpenConnection(winconnString))
                {
                    //Query for selecting the particular product details
                    string query = "SELECT * FROM Product WHERE ProductCode = @ProdCode";
                    //Execute Sqlcommand 
                    using (SqlCommand command = new SqlCommand(query, conn))
                    {
                        //replace the dummy value with userinput
                        command.Parameters.AddWithValue("@ProdCode", productCode);
                        //read the data in the table 
                        using (SqlDataReader reader = await command.ExecuteReaderAsync())
                        {
                            //read each record
                            if (await reader.ReadAsync())
                            {
                                //Return the corresponding product details
                                return new Product
                                {
                                    ProductCode = reader["ProductCode"].ToString(),
                                    ProductName = reader["ProductName"].ToString(),
                                    Category = reader["Category"].ToString(),
                                    Quantity = Convert.ToInt32(reader["Quantity"]),
                                    UnitPrice = Convert.ToDecimal(reader["UnitPrice"]),
                                    IsAvailable = Convert.ToBoolean(reader["IsAvailable"])
                                };
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw new ApplicationException("Error retrieving product by code", ex);
            }
            return null;
        }
        //check the given product code exist or not
        public async Task<bool> ProductCodeExistsAsync(string productCode)
        {
            try
            {
                using (SqlConnection conn = SqlServerConnectionManager.OpenConnection(winconnString))
                {
                    //Query for counting the number of product with same product code
                    string query = "SELECT COUNT(1) FROM Product WHERE ProductCode = @ProdCode";
                    using (SqlCommand command = new SqlCommand(query, conn))
                    {
                        command.Parameters.AddWithValue("@ProdCode", productCode);
                        //store the count 
                        int count = (int)await command.ExecuteScalarAsync();
                        //return true if count greaterthan zero
                        return count > 0;
                    }
                }
            }
            catch (SqlException sqlEx)
            {
                throw new ApplicationException("SQL Error checking product code existence", sqlEx);
            }
            catch (Exception ex)
            {
                throw new ApplicationException("Error checking product code existence", ex);
            }
        }

        //Method for updating the product details
        public async Task UpdateProductAsync(string productCode, Product updatedProduct)
        {
            try
            {
                // Open the connection
                using (SqlConnection conn = SqlServerConnectionManager.OpenConnection(winconnString))
                {
                    //query for updating the details
                    string query = "UPDATE Product SET ProductName = @ProdName, Category = @Category, " +
                                   "Quantity = @Quantity, UnitPrice = @UnitPrice, IsAvailable = @IsAvailable " +
                                   "WHERE ProductCode = @ProdCode";
                    //Execute SqlCommand
                    using (SqlCommand command = new SqlCommand(query, conn))
                    {
                        //replace dummy values with userinput
                        command.Parameters.AddWithValue("@ProdCode", productCode);
                        command.Parameters.AddWithValue("@ProdName", updatedProduct.ProductName);
                        command.Parameters.AddWithValue("@Category", updatedProduct.Category);
                        command.Parameters.AddWithValue("@Quantity", updatedProduct.Quantity);
                        command.Parameters.AddWithValue("@UnitPrice", updatedProduct.UnitPrice);
                        command.Parameters.AddWithValue("@IsAvailable", updatedProduct.IsAvailable);

                        await command.ExecuteNonQueryAsync();
                    }
                }
            }
            catch (Exception ex)
            {
                throw new ApplicationException("Error updating product", ex);
            }
        }
    }
}
