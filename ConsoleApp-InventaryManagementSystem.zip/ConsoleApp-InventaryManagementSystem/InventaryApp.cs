﻿using ConsoleApp_InventaryManagementSystem.Model;
using ConsoleApp_InventaryManagementSystem.Repository;
using System;
using System.Collections.Generic;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using ConsoleApp_InventaryManagementSystem.Service;

namespace ConsoleApp_InventaryManagementSystem

{
   public class InventoryApp
    {
        static async Task Main(string[] args)
        {
            //constructor injuction
            IProductService productService = new ProductServiceImplementation(new ProductRepositoryImplementation());

            //Menu driven
            bool exit = false;
            while (!exit)
            {
                Console.WriteLine("\nInventory Management System");
                Console.WriteLine("1. Add New Product");
                Console.WriteLine("2. Update Product");
                Console.WriteLine("3. Search Product by Code");
                Console.WriteLine("4. Delete Product");
                Console.WriteLine("5. List All Products");
                Console.WriteLine("6. Exit");
                Console.WriteLine("Enter your choice:");
                string choice = Console.ReadLine();
                switch (choice)
                {
                    case "1":
                        await AddProduct(productService);
                        break;
                    case "2":
                        await UpdateProduct(productService);
                        break;
                    case "3":
                        await SearchProduct(productService);
                        break;
                    case "4":
                        await DeleteProduct(productService);
                        break;
                    case "5":
                        await ListAllProducts(productService);
                        break;
                    case "6":
                        exit = true;
                        break;
                    default:
                        Console.WriteLine("Invalid choice. Please enter a number between 1 and 6.");
                        break;
                }
            }
        }
        //Method for adding product
        private static async Task AddProduct(IProductService productService)
        {
            var product = new Product();

            // ProductCode
            while (true)
            {
                Console.Write("Enter the Product Code: ");
                product.ProductCode = Console.ReadLine();
                //check the product code is already exist or not
                if (!string.IsNullOrEmpty(product.ProductCode))
                {
                    bool exists = await productService. ProductCodeExistsAsync(product.ProductCode);
                    if (exists)
                    {
                        Console.WriteLine("Product code already exists. Please enter a unique code.");
                    }
                    else
                    {
                        break;
                    }
                }
                else
                {
                    Console.WriteLine("Product Code cannot be empty.");
                }
            }

            // ProductName
            while (true)
            {
                Console.Write("Enter the Product Name: ");
                product.ProductName = Console.ReadLine();
                //validation for product name
                if (!string.IsNullOrWhiteSpace(product.ProductName) && !Regex.IsMatch(product.ProductName, @"\d"))
                {
                    break;
                }
                else
                {
                    Console.WriteLine("Invalid input for Product Name. It should not be empty and should not contain numbers.");
                }
            }

            // Category
            while (true)
            {
                Console.Write("Enter the Category: ");
                product.Category = Console.ReadLine();
                if (!string.IsNullOrEmpty(product.Category))
                {
                    break;
                }
                else
                {
                    Console.WriteLine("Category cannot be empty.");
                }
            }

            // Quantity
            while (true)
            {
                Console.Write("Enter the Quantity: ");
                if (int.TryParse(Console.ReadLine(), out int quantity) && quantity >= 0)
                {
                    product.Quantity = quantity;
                    break;
                }
                else
                {
                    Console.WriteLine("Invalid input for Quantity. It should be a non-negative number.");
                }
            }

            // UnitPrice
            while (true)
            {
                Console.Write("Enter the Unit Price: ");
                if (decimal.TryParse(Console.ReadLine(), out decimal unitPrice) && unitPrice >= 0)
                {
                    product.UnitPrice = unitPrice;
                    break;
                }
                else
                {
                    Console.WriteLine("Invalid input for Unit Price. It should be a non-negative number.");
                }
            }

            // IsAvailable
            while (true)
            {
                Console.Write("Is the product currently available? (yes/no): ");
                string availableInput = Console.ReadLine().Trim().ToLower();
                //if enter yes product is available
                if (availableInput == "yes" || availableInput == "y")
                {
                    product.IsAvailable = true;
                    break;
                }
                else if (availableInput == "no" || availableInput == "n")
                {
                    product.IsAvailable = false;
                    break;
                }
                else
                {
                    Console.WriteLine("Invalid input for IsAvailable. Please enter 'yes' or 'no'.");
                }
            }
            //add the product details
            await productService.AddProductAsync(product);
            Console.WriteLine("Product added successfully.");
        }
        //Method for updating the details
        private static async Task UpdateProduct(IProductService productService)
        {
            string productCode;
            while (true)
            {
                Console.Write("Enter the Product Code to Update: ");
                productCode = Console.ReadLine();
                if (!string.IsNullOrEmpty(productCode))
                {
                    break;
                }
                else
                {
                    Console.WriteLine("Product Code cannot be empty.");
                }
            }
            //Collect the existing detalis
            Product existingProduct = await productService.GetProductByCodeAsync(productCode);
            if (existingProduct == null)
            {
                Console.WriteLine("Product not found.");
                return;
            }

            // Display current details
            Console.WriteLine("\nCurrent Product Details:");
            Console.WriteLine($"Code: {existingProduct.ProductCode}");
            Console.WriteLine($"Name: {existingProduct.ProductName}");
            Console.WriteLine($"Category: {existingProduct.Category}");
            Console.WriteLine($"Quantity: {existingProduct.Quantity}");
            Console.WriteLine($"Unit Price: {existingProduct.UnitPrice}");
            Console.WriteLine($"Available: {(existingProduct.IsAvailable ? "Yes" : "No")}");

            // Ask for confirmation
            while (true)
            {
                Console.Write("Do you want to edit this product? (yes/no): ");
                string confirmation = Console.ReadLine().Trim().ToLower();
                if (confirmation == "yes" || confirmation == "y")
                {
                    var product = new Product { ProductCode = productCode };

                    // ProductName
                    Console.Write("Enter new Product Name (leave empty to keep existing): ");
                    string newName = Console.ReadLine();
                    if (!string.IsNullOrEmpty(newName) && !Regex.IsMatch(newName, @"\d"))
                    {
                        product.ProductName = newName;
                    }
                    else
                    {
                        product.ProductName = existingProduct.ProductName;
                    }

                    // Category
                    Console.Write("Enter new Category (leave empty to keep existing): ");
                    string newCategory = Console.ReadLine();
                    if (!string.IsNullOrEmpty(newCategory))
                    {
                        product.Category = newCategory;
                    }
                    else
                    {
                        product.Category = existingProduct.Category;
                    }

                    // Quantity
                    Console.Write("Enter new Quantity (leave empty to keep existing): ");
                    string newQuantityInput = Console.ReadLine();
                    //update Quantity
                    if (int.TryParse(newQuantityInput, out int newQuantity) && newQuantity >= 0)
                    {
                        product.Quantity = newQuantity;
                    }
                    else
                    {
                        product.Quantity = existingProduct.Quantity;
                    }

                    // UnitPrice
                    Console.Write("Enter new Unit Price (leave empty to keep existing): ");
                    string newPriceInput = Console.ReadLine();
                    if (decimal.TryParse(newPriceInput, out decimal newPrice) && newPrice >= 0)
                    {
                        product.UnitPrice = newPrice;
                    }
                    else
                    {
                        product.UnitPrice = existingProduct.UnitPrice;
                    }

                    // IsAvailable
                    Console.Write("Is the product currently available? (yes/no) (leave empty to keep existing): ");
                    string newAvailableInput = Console.ReadLine().Trim().ToLower();
                    if (newAvailableInput == "yes" || newAvailableInput == "y")
                    {
                        product.IsAvailable = true;
                    }
                    else if (newAvailableInput == "no" || newAvailableInput == "n")
                    {
                        product.IsAvailable = false;
                    }
                    else
                    {
                        product.IsAvailable = existingProduct.IsAvailable;
                    }

                    await productService.UpdateProductAsync(productCode, product);
                    Console.WriteLine("Product updated successfully.");

                    // Display updated list of all products
                    await ListAllProducts(productService);
                    break;
                }
                else if (confirmation == "no" || confirmation == "n")
                {
                    Console.WriteLine("Update canceled.");
                    break;
                }
                else
                {
                    Console.WriteLine("Invalid input. Please enter 'yes' or 'no'.");
                }
            }
        }
        //Search for a particular product
        private static async Task SearchProduct(IProductService productService)
        {
            string productCode;
            while (true)
            {
                //Ask the product code to search
                Console.Write("Enter the Product Code to Search: ");
                productCode = Console.ReadLine();
                if (!string.IsNullOrEmpty(productCode))
                {
                    break;
                }
                else
                {
                    Console.WriteLine("Product Code cannot be empty.");
                }
            }
            //Collect the details 
            Product product = await productService.GetProductByCodeAsync(productCode);
            if (product == null)
            {
                Console.WriteLine("Product not found.");
            }
            else
            //display the details
            {
                Console.WriteLine("\nProduct Details:");
                Console.WriteLine($"Code: {product.ProductCode}");
                Console.WriteLine($"Name: {product.ProductName}");
                Console.WriteLine($"Category: {product.Category}");
                Console.WriteLine($"Quantity: {product.Quantity}");
                Console.WriteLine($"Unit Price: {product.UnitPrice}");
                Console.WriteLine($"Available: {(product.IsAvailable ? "Yes" : "No")}");
            }
        }

        //Delete a particular product
        private static async Task DeleteProduct(IProductService productService)
        {
            string productCode;
            while (true)
            {
                //Enter the Prduct code which we want to delete
                Console.Write("Enter the Product Code to Delete: ");
                productCode = Console.ReadLine();
                if (!string.IsNullOrEmpty(productCode))
                {
                    break;
                }
                else
                {
                    Console.WriteLine("Product Code cannot be empty.");
                }
            }
            //Collect the details
            Product existingProduct = await productService.GetProductByCodeAsync(productCode);
            if (existingProduct == null)
            {
                Console.WriteLine("Product not found.");
                return;
            }

            while (true)
            {
                //ask whether you want to delete or not
                Console.Write("Are you sure you want to delete this product? (yes/no): ");
                string confirmation = Console.ReadLine().Trim().ToLower();
                if (confirmation == "yes" || confirmation == "y")
                {
                    await productService.DeleteProductAsync(productCode);
                    Console.WriteLine("Product deleted successfully.");
                    //show all product details
                    await ListAllProducts(productService);
                    break;
                }
                else if (confirmation == "no" || confirmation == "n")
                {
                    Console.WriteLine("Deletion canceled.");
                    break;
                }
                else
                {
                    Console.WriteLine("Invalid input. Please enter 'yes' or 'no'.");
                }
            }
        }

        //Show all product details
        private static async Task ListAllProducts(IProductService productService)
        {
            List<Product> products = await productService.GetAllProductsAsync();
            Console.WriteLine("\nProduct List:");
            Console.WriteLine("{0,-15} {1,-25} {2,-20} {3,-10} {4,-10} {5}",
                "Code", "Name", "Category", "Quantity", "Price", "Available");
            foreach (var product in products)
            {
                Console.WriteLine("{0,-15} {1,-25} {2,-20} {3,-10} {4,-10} {5}",
                    product.ProductCode, product.ProductName, product.Category,
                    product.Quantity, product.UnitPrice, product.IsAvailable ? "Yes" : "No");
            }
        }
    }
}
