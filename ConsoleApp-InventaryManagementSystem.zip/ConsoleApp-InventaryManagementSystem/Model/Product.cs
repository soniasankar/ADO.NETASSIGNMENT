﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp_InventaryManagementSystem.Model
{
    public class Product
    {
        //properties of product
        public string ProductCode { get; set; }
        public string ProductName { get; set; }
        public string Category { get; set; }
        public int Quantity { get; set; }
        public decimal UnitPrice { get; set; }
        public bool IsAvailable { get; set; }
        //Default constructor
        public Product()
        {
        }
        //parameterized constructor
        public Product(string productCode, string productName, string category, int quantity, decimal unitPrice,bool isAvailable)
    {
            this.ProductCode = productCode;
            this.ProductName = productName;
            this.Category = category;
            this.Quantity = quantity;
            this.UnitPrice = unitPrice;
            this.IsAvailable = isAvailable;

    }
}
}
