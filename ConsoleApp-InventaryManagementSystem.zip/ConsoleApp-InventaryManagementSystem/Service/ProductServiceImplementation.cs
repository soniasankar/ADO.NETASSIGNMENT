﻿using ConsoleApp_InventaryManagementSystem.Model;
using ConsoleApp_InventaryManagementSystem.Repository;
using ConsoleApp_InventaryManagementSystem.Repository;

using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace ConsoleApp_InventaryManagementSystem.Service
{
    public class ProductServiceImplementation : IProductService
    {
        // Fields
        private readonly IProductRepository _productRepository;

        // Constructor Injection
        public ProductServiceImplementation(IProductRepository productRepository)
        {
            _productRepository = productRepository;
        }

        // Insert a new product
        public async Task AddProductAsync(Product product)
        {
            await _productRepository.AddProductAsync(product);
        }

        // Update an existing product by its product code
        public async Task UpdateProductAsync(string productCode, Product updatedProduct)
        {
            await _productRepository.UpdateProductAsync(productCode, updatedProduct);
        }

        // Get all products
        public async Task<List<Product>> GetAllProductsAsync()
        {
            return await _productRepository.GetAllProductsAsync();
        }

        // Search for a product by its product code
        public async Task<Product> GetProductByCodeAsync(string productCode)
        {
            return await _productRepository.GetProductByCodeAsync(productCode);
        }

        // Delete a product by its product code
        public async Task DeleteProductAsync(string productCode)
        {
            await _productRepository.DeleteProductAsync(productCode);
        }

        // Check if a product code exists
        public async Task<bool> ProductCodeExistsAsync(string productCode)
        {
            return await _productRepository.ProductCodeExistsAsync(productCode);
        }
    }
}
