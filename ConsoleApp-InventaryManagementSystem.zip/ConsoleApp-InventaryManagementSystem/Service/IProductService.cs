﻿using ConsoleApp_InventaryManagementSystem.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp_InventaryManagementSystem.Repository
{
    public interface IProductService
    {

        // Data Access Layer

        // Insert a new product
        Task AddProductAsync(Product product);

        // Update an existing product by its product code
        Task UpdateProductAsync(string productCode, Product updatedProduct);

        // Search for a product by its product code
        Task<Product> GetProductByCodeAsync(string productCode);

        Task<bool> ProductCodeExistsAsync(string productCode);

        // List all products
        Task<List<Product>> GetAllProductsAsync();

        // Delete a product by its product code
        Task DeleteProductAsync(string productCode);
    }
}
