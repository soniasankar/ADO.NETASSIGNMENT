﻿using ConsoleApp_LibraryManagementCRUD.Model;
using ConsoleApp_LibraryManagementCRUD.Repository;
using ConsoleApp_LibraryManagementCRUD.Service;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace ConsoleApp_LibraryManagementCRUD
{
    internal class BookApp
    {
        static async Task Main(string[] args)
        {
            //constructor Injuction
            IBookService bookService = new BookServiceImplementation(new BookRepositoryImpl());

            bool exit = false;
            //Menu Driven
            while (!exit)
            {
                Console.WriteLine("\nBook Management System");
                Console.WriteLine("1. Add New Book");
                Console.WriteLine("2. Update Book");
                Console.WriteLine("3. Search Book by Code");
                Console.WriteLine("4. Delete Book");
                Console.WriteLine("5. List All Books");
                Console.WriteLine("6. Exit");
                Console.WriteLine("Enter your choice:");
                string choice = Console.ReadLine();
                switch (choice)
                {
                    case "1":
                        
                        await AddBook(bookService);
                        break;
                    case "2":
                        await UpdateBook(bookService);
                        break;
                    case "3":
                        await SearchBook(bookService);
                        break;
                    case "4":
                        await DeleteBook(bookService);
                        break;
                    case "5":
                        await ListAllBooks(bookService);
                        break;
                    case "6":
                        exit = true;
                        break;
                    default:
                        Console.WriteLine("Invalid choice. Please enter a number between 1 and 6.");
                        break;
                }
            }
        }
        //Add book method
        private static async Task AddBook(IBookService bookService)
        {
            var book = new Book();

            // BookCode
            while (true)
            {//endter the book code
                Console.Write("Enter the Book Code: ");
                book.BookCode = Console.ReadLine();
                if (!string.IsNullOrEmpty(book.BookCode))
                {
                    //check the book exist 
                    bool exists = await bookService.BookCodeExist(book.BookCode);
                    if (exists)
                    {
                        Console.WriteLine("Book Code already exists. Please enter a unique Book Code.");
                    }
                    else
                    {
                        break;
                    }
                }
                else
                {
                    Console.WriteLine("Book Code cannot be empty.");
                }
            }

            // Title
            while (true)
            {
                //add title
                Console.Write("Enter the Title: ");
                book.Title = Console.ReadLine();
                if (!string.IsNullOrWhiteSpace(book.Title))
                {
                    break;
                }
                else
                {
                    Console.WriteLine("Title cannot be empty.");
                }
            }

            // Author
            while (true)
            {
                //add author
                Console.Write("Enter the Author: ");
                book.Author = Console.ReadLine();
                if (!string.IsNullOrWhiteSpace(book.Author))
                {
                    break;
                }
                else
                {
                    Console.WriteLine("Author cannot be empty.");
                }
            }

            // Genre
            while (true)
            {
                //add genre
                Console.Write("Enter the Genre: ");
                book.Genre = Console.ReadLine();
                if (!string.IsNullOrWhiteSpace(book.Genre))
                {
                    break;
                }
                else
                {
                    Console.WriteLine("Genre cannot be empty.");
                }
            }

            // Price
            while (true)
            {
                //add price
                Console.Write("Enter the Price: ");
                if (decimal.TryParse(Console.ReadLine(), out decimal price) && price >= 0)
                {
                    book.Price = price;
                    break;
                }
                else
                {
                    Console.WriteLine("Invalid input for Price. It should be a non-negative number.");
                }
            }

            // IsAvailable
            while (true)
            {
                //Add the book Available
                Console.Write("Is the book available? (yes/no): ");
                string availabilityInput = Console.ReadLine().Trim().ToLower();
                if (availabilityInput == "yes" || availabilityInput == "y")
                {
                    //true if book is available
                    book.IsAvailable = true;
                    break;
                }
                else if (availabilityInput == "no" || availabilityInput == "n")
                {
                    book.IsAvailable = false;
                    break;
                }
                else
                {
                    Console.WriteLine("Invalid input for Availability. Please enter 'yes' or 'no'.");
                }
            }
            //adding books 
            await bookService.AddBook(book);
            Console.WriteLine("Book added successfully.");
        }

        //Method for update
        private static async Task UpdateBook(IBookService bookService)
        {
            string bookCode;
            while (true)
            {
                //input the book code to update
                Console.Write("Enter the Book Code to Update: ");
                bookCode = Console.ReadLine();
                if (!string.IsNullOrEmpty(bookCode))
                {
                    break;
                }
                else
                {
                    Console.WriteLine("Book Code cannot be empty.");
                }
            }
            //check the code exist or not
            Book existingBook = await bookService.SearchBookByCode(bookCode);
            if (existingBook == null)
            {
                Console.WriteLine("Book not found.");
                return;
            }

            // Display current details
            Console.WriteLine("\nCurrent Book Details:");
            Console.WriteLine($"Book Code: {existingBook.BookCode}");
            Console.WriteLine($"Title: {existingBook.Title}");
            Console.WriteLine($"Author: {existingBook.Author}");
            Console.WriteLine($"Genre: {existingBook.Genre}");
            Console.WriteLine($"Price: {existingBook.Price}");
            Console.WriteLine($"Available: {(existingBook.IsAvailable ? "Yes" : "No")}");

            // Ask for confirmation
            while (true)
            {
                Console.Write("Do you want to edit this book? (yes/no): ");
                string confirmation = Console.ReadLine().Trim().ToLower();
                if (confirmation == "yes" || confirmation == "y")
                {
                    var book = new Book { BookCode = bookCode };

                    // Title
                    Console.Write("Enter new Title (leave empty to keep existing): ");
                    string newTitle = Console.ReadLine();
                    if (!string.IsNullOrEmpty(newTitle))
                    {
                        book.Title = newTitle;
                    }
                    else
                    {
                        book.Title = existingBook.Title;
                    }

                    // Author
                    Console.Write("Enter new Author (leave empty to keep existing): ");
                    string newAuthor = Console.ReadLine();
                    if (!string.IsNullOrEmpty(newAuthor))
                    {
                        book.Author = newAuthor;
                    }
                    else
                    {
                        book.Author = existingBook.Author;
                    }

                    // Genre
                    Console.Write("Enter new Genre (leave empty to keep existing): ");
                    string newGenre = Console.ReadLine();
                    if (!string.IsNullOrEmpty(newGenre))
                    {
                        book.Genre = newGenre;
                    }
                    else
                    {
                        book.Genre = existingBook.Genre;
                    }

                    // Price
                    Console.Write("Enter new Price (leave empty to keep existing): ");
                    string newPriceInput = Console.ReadLine();
                    if (decimal.TryParse(newPriceInput, out decimal newPrice) && newPrice >= 0)
                    {
                        book.Price = newPrice;
                    }
                    else
                    {
                        book.Price = existingBook.Price;
                    }

                    // IsAvailable
                    Console.Write("Enter new Availability (leave empty to keep existing): ");
                    string availabilityInput = Console.ReadLine().Trim().ToLower();
                    if (availabilityInput == "yes" || availabilityInput == "y")
                    {
                        book.IsAvailable = true;
                    }
                    else if (availabilityInput == "no" || availabilityInput == "n")
                    {
                        book.IsAvailable = false;
                    }
                    else
                    {
                        book.IsAvailable = existingBook.IsAvailable;
                    }

                    await bookService.UpdateBook(bookCode, book);
                    Console.WriteLine("Book updated successfully.");

                    // Display updated list of all books
                    await ListAllBooks(bookService);
                    break;
                }
                else if (confirmation == "no" || confirmation == "n")
                {
                    Console.WriteLine("Update canceled.");
                    break;
                }
                else
                {
                    Console.WriteLine("Invalid input. Please enter 'yes' or 'no'.");
                }
            }
        }
        //Method for search

        private static async Task SearchBook(IBookService bookService)
        {
            string bookCode;
            while (true)
            {
                Console.Write("Enter the Book Code to Search: ");
                bookCode = Console.ReadLine();
                if (!string.IsNullOrEmpty(bookCode))
                {
                    break;
                }
                else
                {
                    Console.WriteLine("Book Code cannot be empty.");
                }
            }
            //check the book with the input code exist
            Book book = await bookService.SearchBookByCode(bookCode);
            if (book == null)
            {
                Console.WriteLine("Book not found.");
            }
            else
            {
                //display the details
                Console.WriteLine("\nBook Details:");
                Console.WriteLine();
                Console.WriteLine("| {0,-12} | {1,-30} | {2,-25} | {3,-20} | {4,-10} | {5,-8} |",
                    "Book Code", "Title", "Author", "Genre", "Price", "Available");
                Console.WriteLine();
                Console.WriteLine("| {0,-12} | {1,-30} | {2,-25} | {3,-20} | {4,-10} | {5,-8} |",
                    book.BookCode, book.Title, book.Author, book.Genre, book.Price, book.IsAvailable ? "Yes" : "No");
                Console.WriteLine();
            }
        }

        //Method for deleting the book
        private static async Task DeleteBook(IBookService bookService)
        {
            string bookCode;
            while (true)
            {
                Console.Write("Enter the Book Code to Delete: ");
                bookCode = Console.ReadLine();
                if (!string.IsNullOrEmpty(bookCode))
                {
                    break;
                }
                else
                {
                    Console.WriteLine("Book Code cannot be empty.");
                }
            }
            //Display book details after deletion
            Book existingBook = await bookService.SearchBookByCode(bookCode);
            if (existingBook == null)
            {
                Console.WriteLine("Book not found.");
                return;
            }

            while (true)
            {
                //ask confirmation from user to delete the details
                Console.Write("Are you sure you want to delete this book? (yes/no): ");
                string confirmation = Console.ReadLine().Trim().ToLower();
                if (confirmation == "yes" || confirmation == "y")
                {
                    //call deleteBook Method
                    await bookService.DeleteBook(bookCode);
                    Console.WriteLine("Book deleted successfully.");
                    //show the list after deletion
                    await ListAllBooks(bookService);
                    break;
                }
                else if (confirmation == "no" || confirmation == "n")
                {
                    Console.WriteLine("Deletion canceled.");
                    break;
                }
                else
                {
                    Console.WriteLine("Invalid input. Please enter 'yes' or 'no'.");
                }
            }
        }

        //show all books
        private static async Task ListAllBooks(IBookService bookService)
        {
            List<Book> books = await bookService.GetAllBooks();
            if (books.Count == 0)
            {
                Console.WriteLine("No books found.");
            }
            else
            {
                //display the book details
                Console.WriteLine("\nList of All Books:");
                Console.WriteLine();
                Console.WriteLine("| {0,-12} | {1,-30} | {2,-25} | {3,-20} | {4,-10} | {5,-8} |",
                    "Book Code", "Title", "Author", "Genre", "Price", "Available");
                Console.WriteLine();
                foreach (var book in books)
                {
                    Console.WriteLine("| {0,-12} | {1,-30} | {2,-25} | {3,-20} | {4,-10} | {5,-8} |",
                        book.BookCode, book.Title, book.Author, book.Genre, book.Price, book.IsAvailable ? "Yes" : "No");
                }
                Console.WriteLine();
            }
        }
    }
}
