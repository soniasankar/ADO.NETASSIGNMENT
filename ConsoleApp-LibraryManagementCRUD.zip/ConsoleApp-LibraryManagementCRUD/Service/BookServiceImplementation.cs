﻿using ConsoleApp_LibraryManagementCRUD.Model;
using ConsoleApp_LibraryManagementCRUD.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Runtime.Remoting.Messaging;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp_LibraryManagementCRUD.Service
{
    public class BookServiceImplementation : IBookService
    {
        private readonly IBookRepository _bookRepository;
        //Constructor injuection
        public BookServiceImplementation(IBookRepository bookRepository)
            {
                _bookRepository = bookRepository ;
            }
        //Method for adding
        public async Task AddBook(Book book)
        {
            await _bookRepository.AddBook(book);
        }
        //check the bookcode exist or not
        public async Task<bool> BookCodeExist(string bookCode)
        {
           return await _bookRepository.BookCodeExist(bookCode);
        }
        //Method for deleting
        public async Task DeleteBook(string bookCode)
        {
            await _bookRepository.DeleteBook(bookCode);
        }
        //Method for collecting all book details
        public async Task<List<Book>> GetAllBooks()
        {
            return await _bookRepository.GetAllBooks();
        }
        //Search for a particual Book using Bookcode
        public async Task<Book> SearchBookByCode(string bookCode)
        {
            return await _bookRepository. SearchBookByCode(bookCode);
        }

        public async Task UpdateBook(string bookCode, Book updateBook)
        {
            await _bookRepository. UpdateBook(bookCode, updateBook);
        }
    }
}
