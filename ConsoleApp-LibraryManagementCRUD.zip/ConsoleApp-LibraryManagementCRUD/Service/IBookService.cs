﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ConsoleApp_LibraryManagementCRUD.Model;
using ConsoleApp_LibraryManagementCRUD.Repository;

namespace ConsoleApp_LibraryManagementCRUD.Service
{
   public interface IBookService
    {

        //add book
        Task AddBook(Book book);

        //update book
        Task UpdateBook(string bookCode, Book updateBook);
        //search a particular book
        Task<Book> SearchBookByCode(string bookCode);
        //method to get list of books
        Task<List<Book>> GetAllBooks();
        //method for deleting a book 
        Task DeleteBook(string bookCode);
        //method to check book with specified code is present or not
        Task<bool> BookCodeExist(string bookCode);
    }
}
