﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web;
using System.Configuration;
using SqlServerConnectionLibrary;
using System.Data.SqlClient;
using ConsoleApp_LibraryManagementCRUD.Model;
using ConsoleApp_LibraryManagementCRUD.Repository;
using System.ComponentModel.Design;
using System.CodeDom.Compiler;
using System.Diagnostics;

namespace ConsoleApp_LibraryManagementCRUD.Repository
{
    public class BookRepositoryImpl : IBookRepository
    {
        //retrive the connecion from app.config
        private readonly string retriveConn = ConfigurationManager.ConnectionStrings["CsWin"].ConnectionString;
        //add book method


        public async Task AddBook(Book book)
        {
            try
            {
                using (SqlConnection conn = SqlServerConnectionManager.OpenConnection(retriveConn))
                {
                    string query = "INSERT INTO Book(BookCode,Title,Author,Genre,Price,IsAvailable)" +
                        "VALUES(@BookCode, @Title, @Author, @Genre, @Price, @IsAvailable)";

                    using (SqlCommand command = new SqlCommand(query, conn))
                    {

                        command.Parameters.AddWithValue("@BookCode", book.BookCode);
                        command.Parameters.AddWithValue("@Title", book.Title);
                        command.Parameters.AddWithValue("@Author", book.Author);
                        command.Parameters.AddWithValue("@Genre", book.Genre);
                        command.Parameters.AddWithValue("@Price", book.Price);
                        command.Parameters.AddWithValue("@IsAvailable", book.IsAvailable);

                        await command.ExecuteNonQueryAsync();

                    }
                }
            }
            catch (Exception ex)
            {
                throw new ApplicationException("Error adding book", ex);
            }
        }
    
        //For checking BookCode exist or not
        public async Task<bool> BookCodeExist(string bookCode)
        {
            try
            {


                using (SqlConnection conn = SqlServerConnectionManager.OpenConnection(retriveConn))
                {

                    string query = "SELECT COUNT(1) FROM Book WHERE BookCode = @BookCode";
                    //Execute the command
                    using (SqlCommand command = new SqlCommand(query, conn))
                    {
                        //Add the userinput to dummy values
                        command.Parameters.AddWithValue("@Bookcode", bookCode);
                        int count = (int)await command.ExecuteScalarAsync();
                        return count > 0;
                    }

                }
            }
            catch (SqlException sqlEx)
            {
                throw new ApplicationException("SQL Error checking book code existence", sqlEx);
            }
            catch (Exception ex)
            {
                throw new ApplicationException("Error checking book code existence", ex);
            }

        }

        //code for deleting a  book
        public async Task DeleteBook(string bookCode)
        {
            try
            {
                //open connection
                using (SqlConnection conn = SqlServerConnectionManager.OpenConnection(retriveConn))
                {
                    //query for update IsAvailable value to zero inorder to delete the data
                    string query = "UPDATE Book SET IsAvailabe=0 WHERE @BookCode=BookCode";
                    using (SqlCommand command = new SqlCommand(query, conn))
                    {
                        command.Parameters.AddWithValue("@BookCode", bookCode);
                        await command.ExecuteNonQueryAsync();
                    }
                }
            }
            catch (SqlException Sqlex)
            {
                throw new ApplicationException("Sql error no book with this bookcode",Sqlex);
            }
            catch(Exception ex)
            {
                throw new ApplicationException("Error deleting book", ex);
            }
        }
        //Method for getting list of books
        public async Task<List<Book>> GetAllBooks()
        {
            var books= new List<Book>();
            try
            {

                using (SqlConnection conn = SqlServerConnectionManager.OpenConnection(retriveConn))
                {
                    //query for selection
                    string query = "SELECT * FROM Book";
                    //for executing sql command against database
                    using (SqlCommand command = new SqlCommand(query, conn))
                    {

                        //Execute the query and get a data reader
                        using (SqlDataReader reader = await command.ExecuteReaderAsync())
                        {
                            // Read and process each book record
                            while (await reader.ReadAsync())
                            {
                                var bookss = new Book
                                {
                                    BookCode = reader["BookCode"].ToString(),
                                    Title = reader["Title"].ToString(),
                                    Author = reader["Author"].ToString(),
                                    Genre = reader["Genre"].ToString(),
                                    Price = Convert.ToDecimal(reader["Price"]),
                                    IsAvailable = Convert.ToBoolean(reader["IsAvailable"])

                                }
                                ;
                                books.Add(bookss);
                            }
                        }
                    }

                }
                return books;
              
            

            }
            catch(Exception ex)
            {
                throw new ApplicationException("Error retrieving book by code", ex);
            }
        }

        public async Task<Book> SearchBookByCode(string bookCode)
        {
            try
            {
                //retrive the connection
                using (SqlConnection conn = SqlServerConnectionManager.OpenConnection(retriveConn))
                {
                    //Query for selection 
                    string Query = "SELECT * FROM Book WHERE BookCode= @BookCode";
                    using (SqlCommand command = new SqlCommand(Query, conn))
                    {
                        command.Parameters.AddWithValue("@BookCode", bookCode);
                        using (SqlDataReader reader = await command.ExecuteReaderAsync())
                        {
                            if (await reader.ReadAsync())
                            {
                                return new Book
                                {
                                    BookCode = reader["BookCode"].ToString(),
                                    Title = reader["Title"].ToString(),
                                    Author = reader["Author"].ToString(),
                                    Genre = reader["Genre"].ToString(),
                                    Price = Convert.ToDecimal(reader["Price"]),
                                    IsAvailable = Convert.ToBoolean(reader["IsAvailable"]),


                                };
                            }
                            else
                            {
                                return null;
                            }

                        }
                    }

                }
            }
            catch (Exception ex)
            {
                throw new ApplicationException("Error retrieving book by code", ex);
            }
        }

        public async Task UpdateBook(string bookCode, Book updateBook)
        {
            try
            {
                // Open a connection to the database
                using (SqlConnection conn = SqlServerConnectionManager.OpenConnection(retriveConn))
                {
                    // SQL query to update the book details
                    string query = "UPDATE Book SET Title = @Title, Author = @Author, Genre = @Genre, Price = @Price, IsAvailable = @IsAvailable " +
                                   "WHERE BookCode = @BookCode";

                    // Execute sqlCommand
                    using (SqlCommand command = new SqlCommand(query, conn))
                    {
                        // Add parameters with new values for the book
                        command.Parameters.AddWithValue("@BookCode", bookCode);
                        command.Parameters.AddWithValue("@Title", updateBook.Title);
                        command.Parameters.AddWithValue("@Author", updateBook.Author);
                        command.Parameters.AddWithValue("@Genre", updateBook.Genre);
                        command.Parameters.AddWithValue("@Price", updateBook.Price);
                        command.Parameters.AddWithValue("@IsAvailable", updateBook.IsAvailable);

                        // Execute the command asynchronously
                        await command.ExecuteNonQueryAsync();
                    }
                }
            }
            catch (Exception ex)
            {
                
                throw new ApplicationException("Error updating book", ex);
            }
        }

    }
}
